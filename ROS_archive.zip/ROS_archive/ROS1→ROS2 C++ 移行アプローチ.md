# ROS1 Noetic → ROS2 Humble C++パッケージ移行アプローチ

このドキュメントは、ROS1 Noeticで開発されたC++パッケージをROS2 Humbleに移行するための、現場目線の具体的な手順と注意点をまとめたものです。ステップ形式で整理されています。

---

## 1. 現行パッケージの整理と要素分解

**概要**  
既存のROS1パッケージの構成・依存・機能要素を整理して、移植対象のスコープと優先度を明確にします。

| 項目 | 内容 |
|------|------|
| パッケージ構成 | `package.xml`, `CMakeLists.txt` |
| 実装構成 | ノード数、トピック、サービス、アクション、パラメータなど |
| 外部依存 | OpenCV, Eigen などのライブラリ依存の洗い出し |

---

## 2. ROS2パッケージの雛形作成

**概要**  
ROS2準拠のC++パッケージ雛形を `ros2 pkg create` コマンドで作成し、ビルドツールと構成ファイルをROS2向けに変更します。

```bash
ros2 pkg create --build-type ament_cmake my_converted_package
```

---

## 3. ノード実装の移行（逐次対応）

**概要**  
ROS1の各ノードをROS2形式に1つずつ置き換えます。小さな単位で移植・検証を繰り返します。

| 要素 | ROS1 | ROS2 |
|------|------|------|
| ノード初期化 | `ros::init()` | `rclcpp::init()` |
| ノード作成 | `NodeHandle` | `rclcpp::Node::make_shared()` |
| pub/sub | `advertise/subscribe` | `create_publisher/create_subscription` |
| callback形式 | bind/関数 | ラムダ式 |
| パラメータ取得 | `getParam()` | `declare_parameter()`, `get_parameter()` |
| サービス | `advertiseService()` | `create_service()` |
| タイマー | `createTimer()` | `create_wall_timer()` |

---

## 4. CMakeLists.txtの更新

**概要**  
`catkin`から`ament_cmake`への書き換え。パッケージ依存やインストール先も明示します。

```cmake
find_package(ament_cmake REQUIRED)
find_package(rclcpp REQUIRED)
find_package(std_msgs REQUIRED)

add_executable(my_node src/my_node.cpp)
ament_target_dependencies(my_node rclcpp std_msgs)

install(TARGETS my_node
  DESTINATION lib/${PROJECT_NAME}
)

ament_package()
```

---

## 5. ビルド・通信動作確認

**概要**  
ROS2ノードを `ros2 run` で起動し、トピック送受信やパラメータ読み込みが正常に動作するか確認します。

```bash
ros2 run my_converted_package my_node
ros2 topic echo /my_topic
```

---

## 6. ROS1ブリッジ（必要に応じて）

**概要**  
移行途中でROS1ノードとの通信が必要な場合は、`ros1_bridge`を利用します。

```bash
source /opt/ros/noetic/setup.bash
source /opt/ros/humble/setup.bash
ros2 run ros1_bridge dynamic_bridge
```

---

## 7. Launchファイルの変換（XML）

**概要**  
ROS1の `.launch` ファイルを `.launch.xml` に変換します。Python形式も選択可能ですが、ここではXML形式に統一します。

**ROS1**
```xml
<launch>
  <node name="talker" pkg="my_package" type="talker" output="screen" />
</launch>
```

**ROS2**
```xml
<launch>
  <node pkg="my_package" exec="talker" name="talker" output="screen"/>
</launch>
```

---

## 8. ユニットテストとCI移行

**概要**  
ROS1の `rostest` から、ROS2の `ament_cmake_gtest` や `launch_testing` に切り替えます。

**CMakeLists.txt への追加例**
```cmake
find_package(ament_cmake_gtest REQUIRED)
ament_add_gtest(my_test test/test_node.cpp)
```

---

## 9. コード最適化・API置換

**概要**  
ROS2非対応の古いAPIやBoost依存コードを、モダンなC++17ベースに整理・置換します。

- `ros::Time::now()` → `get_clock()->now()`
- `boost::shared_ptr` → `std::shared_ptr`

---

## 10. READMEとビルド手順の更新

**概要**  
移行後の使用方法（`colcon build`, `ros2 run`, `ros2 launch`）をREADMEやドキュメントに明記します。

---

