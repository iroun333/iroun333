# 📂 ステップ1：現行パッケージの整理と要素分解

## 2. パッケージ構成の確認 → CMakeLists.txt の構造確認

---

## ✅ 目的

`CMakeLists.txt` は、ROSパッケージのビルド・依存管理・インストール・テスト構成を定義する最重要ファイルです。
ROS1（Noetic）の `catkin` ビルドシステムと、ROS2（Humble）の `ament_cmake` では記述スタイル・依存指定方法が大きく異なるため、**現行構造の把握と移行方針の明確化**が必要です。

---

## ✅ 主なチェック対象とその役割（ROS1基準）

| 構文 / ディレクティブ                                 | 用途・機能                               | ROS2での対応                                  | 備考                                        |
| -------------------------------------------- | ----------------------------------- | ----------------------------------------- | ----------------------------------------- |
| `cmake_minimum_required()`                   | CMakeの最低バージョンを指定                    | そのまま使用（ROS2では3.5以上が基本）                    | 環境によっては更に高いバージョンが必要                       |
| `project()`                                  | パッケージ名、C++標準設定などを定義                 | 同様に使用                                     | C++17 または C++20 の明記が一般的                   |
| `set(CMAKE_CXX_STANDARD ...)`                | 使用するC++のバージョンを指定                    | 必須                                        | `CMAKE_CXX_STANDARD 17` 推奨                |
| `add_compile_options()`                      | コンパイルオプションの追加（例：`-Wall`, `-Wextra`） | 同様に使用可                                    | 静的解析や品質担保に役立つ                             |
| `find_package()`                             | 依存ライブラリ・パッケージを検索                    | `ament_cmake`, `rclcpp` などに置換             | 依存パッケージを個別に指定する必要がある                      |
| `catkin_package()`                           | catkin依存・エクスポート情報を登録                | 不要                                        | ROS2では `ament_package()` を使用              |
| `include_directories()`                      | ヘッダファイル探索パスの指定                      | 非推奨                                       | ROS2では `target_include_directories()` に置換 |
| `add_executable()`                           | 実行ファイル（ノード）を登録                      | 同様に使用                                     | ノードごとに明示的に指定する                            |
| `target_link_libraries()`                    | ライブラリをノードにリンク                       | `ament_target_dependencies()` を併用         | 外部・内部ライブラリを正確に指定する                        |
| `add_dependencies()`                         | 他のCMakeターゲットとのビルド順序制御               | ROS2では `rosidl_generate_interfaces()` に統合 | msg/srv使用時に重要な制御要素                        |
| `add_library()`                              | 再利用可能なクラス/関数をライブラリとして定義             | 同様に使用                                     | 複数ノードで共通機能を共有する際に重要                       |
| `install(TARGETS ...)`                       | 実行ファイルのインストール先を指定                   | 必須                                        | ROS2では明示的に書かないと colcon が認識しない             |
| `install(DIRECTORY include/...)`             | ヘッダファイルのインストール指定                    | 同様に使用                                     | クラスベースのパッケージで必要になる                        |
| `generate_messages()`, `add_message_files()` | カスタムmsg/srvファイルの生成定義                | `rosidl_generate_interfaces()` に変換        | 依存指定とセットで変更が必要                            |
| `enable_testing()`                           | テストの有効化                             | 同様に使用                                     | `ament_add_gtest()` などと併用                 |
| `add_rostest()`                              | rostest による統合テスト                    | `ament_add_gtest()`, `launch_testing` へ置換 | 完全な移行には test用launchファイル再構成が必要             |
| `pluginlib_export_class()`                   | Nodeletなどプラグインの定義                   | `RCLCPP_COMPONENTS_REGISTER_NODE()` に置換   | ROS2ではComposable Node構成で利用                |

---

## ✅ 実例：典型的な記述とその変換例

### 🔹 ROS1（CMakeLists.txt）

```cmake
cmake_minimum_required(VERSION 3.0.2)
project(my_package)

add_compile_options(-Wall -Wextra)

find_package(catkin REQUIRED COMPONENTS
  roscpp
  std_msgs
  message_generation
)

add_message_files(FILES MyMsg.msg)
generate_messages(DEPENDENCIES std_msgs)

catkin_package(CATKIN_DEPENDS roscpp std_msgs message_runtime)

include_directories(
  include
  ${catkin_INCLUDE_DIRS}
)

add_executable(my_node src/my_node.cpp)
add_dependencies(my_node ${${PROJECT_NAME}_EXPORTED_TARGETS} ${catkin_EXPORTED_TARGETS})
target_link_libraries(my_node ${catkin_LIBRARIES})

install(TARGETS my_node
  RUNTIME DESTINATION ${CATKIN_PACKAGE_BIN_DESTINATION}
)
```

---

### 🔹 ROS2（CMakeLists.txt）

```cmake
cmake_minimum_required(VERSION 3.5)
project(my_package)

add_compile_options(-Wall -Wextra)

find_package(ament_cmake REQUIRED)
find_package(rclcpp REQUIRED)
find_package(std_msgs REQUIRED)

rosidl_generate_interfaces(${PROJECT_NAME}
  "msg/MyMsg.msg"
  DEPENDENCIES std_msgs
)

add_executable(my_node src/my_node.cpp)
ament_target_dependencies(my_node rclcpp std_msgs)

install(TARGETS my_node
  DESTINATION lib/${PROJECT_NAME}
)

ament_package()
```

---

## ✅ チェック作業のすすめ方（推奨）

1. `CMakeLists.txt` に含まれる構文を一通りチェック
2. msg/srv 使用有無に応じて `generate_messages()` / `add_dependencies()` を確認
3. ヘッダ/ソース分離されている構成で `add_library()` の有無をチェック
4. `install()` セクションの有無・正確性を確認（ROS2では必須）
5. テストやplugin構成がある場合は、移行後の互換性と代替構文を洗い出す

---
