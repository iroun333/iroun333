# ROS1 Noetic → ROS2 Humble C++ 典型的なコード差分と概要解説

記録用：構文やAPIの違いを項目別に整理

---

## 1. ノード初期化とスピン

**概要**  
ROS1では `ros::init()` + `ros::NodeHandle` を使ってノードを構築。  
ROS2では `rclcpp::Node::make_shared()` により `shared_ptr` でノードを生成。  
終了時に `rclcpp::shutdown()` を必ず呼ぶ。

**コード比較**

**ROS1**
```cpp
ros::init(argc, argv, "simple_node");
ros::NodeHandle nh;
ros::spin();
```

**ROS2**
```cpp
rclcpp::init(argc, argv);
auto node = rclcpp::Node::make_shared("simple_node");
rclcpp::spin(node);
rclcpp::shutdown();
```

---

## 2. Publisher / Subscriber

**概要**  
トピック通信は `advertise()` / `subscribe()` → `create_publisher()` / `create_subscription()` に変更。  
コールバックにはラムダ式が多用される。  
QoS（通信品質）指定が**必須**。

**コード比較**

**ROS1**
```cpp
ros::Publisher pub = nh.advertise<std_msgs::String>("topic", 10);
ros::Subscriber sub = nh.subscribe("topic", 10, callback);
```

**ROS2**
```cpp
auto pub = node->create_publisher<std_msgs::msg::String>("topic", 10);
auto sub = node->create_subscription<std_msgs::msg::String>(
  "topic", 10,
  [](const std_msgs::msg::String::SharedPtr msg) {
    RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "%s", msg->data.c_str());
  });
```

---

## 3. サービス（Server）

**概要**  
ROS1では同期的な `advertiseService()` を使うが、ROS2では非同期でラムダ式が主流。  
型指定に `::srv::` 名前空間が必要。

**コード比較**

**ROS1**
```cpp
ros::ServiceServer service = nh.advertiseService("reset", handle);
```

**ROS2**
```cpp
auto service = node->create_service<std_srvs::srv::Empty>(
  "reset",
  [](const std::shared_ptr<std_srvs::srv::Empty::Request> request,
     std::shared_ptr<std_srvs::srv::Empty::Response> response) {
    (void)request;
    RCLCPP_INFO(node->get_logger(), "Service called");
  });
```

---

## 4. タイマー処理

**概要**  
ROS1では `ros::Timer` を使い、ROS2では `create_wall_timer()` を使用。  
クロックは `std::chrono` に基づく。

**コード比較**

**ROS1**
```cpp
ros::Timer timer = nh.createTimer(ros::Duration(1.0), callback);
```

**ROS2**
```cpp
auto timer = node->create_wall_timer(
  std::chrono::seconds(1),
  []() {
    RCLCPP_INFO(rclcpp::get_logger("rclcpp"), "Timer triggered");
  });
```

---

## 5. パラメータ取得

**概要**  
ROS1の `getParam()` に対し、ROS2では `declare_parameter()` で宣言し `get_parameter()` を併用。

**コード比較**

**ROS1**
```cpp
int val;
nh.getParam("my_param", val);
```

**ROS2**
```cpp
int val = node->declare_parameter<int>("my_param", 0);
```

---

## 6. ログ出力

**概要**  
ROS2ではログ出力時に `logger` の指定が必要。

**ログマクロ比較**

| レベル | ROS1            | ROS2                        |
|--------|------------------|-----------------------------|
| info   | `ROS_INFO(...)`  | `RCLCPP_INFO(logger, ...)`  |
| warn   | `ROS_WARN(...)`  | `RCLCPP_WARN(logger, ...)`  |
| error  | `ROS_ERROR(...)` | `RCLCPP_ERROR(logger, ...)` |
| debug  | `ROS_DEBUG(...)` | `RCLCPP_DEBUG(logger, ...)` |

---

# 🔽 補足

## A. クラス型ノードの実装（rclcpp::Node 継承）
```cpp
class MyNode : public rclcpp::Node {
public:
  MyNode() : Node("my_node") {
    RCLCPP_INFO(this->get_logger(), "MyNode initialized");
  }
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MyNode>());
  rclcpp::shutdown();
}
```

---

## B. QoSプロファイルの指定
```cpp
#include "rclcpp/qos.hpp"
rclcpp::QoS qos_profile(rclcpp::KeepLast(10));
qos_profile.reliable();     // または .best_effort()
qos_profile.durability_volatile(); // または .durability_transient_local()
```

---

## C. Publisher + Service 複合ノード
```cpp
class HybridNode : public rclcpp::Node {
public:
  HybridNode() : Node("hybrid_node") {
    pub_ = this->create_publisher<std_msgs::msg::String>("chatter", 10);
    srv_ = this->create_service<std_srvs::srv::Trigger>(
      "trigger",
      [this](const std::shared_ptr<std_srvs::srv::Trigger::Request> req,
             std::shared_ptr<std_srvs::srv::Trigger::Response> res) {
        (void)req;
        RCLCPP_INFO(this->get_logger(), "Trigger received");
        std_msgs::msg::String msg;
        msg.data = "Hello from service!";
        pub_->publish(msg);
        res->success = true;
      });
  }
private:
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr pub_;
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr srv_;
};
```

---

## D. Launchファイル構文（XMLでの比較）

**ROS1**
```xml
<launch>
  <node name="talker" pkg="my_package" type="talker" output="screen" />
</launch>
```

**ROS2**
```xml
<launch>
  <node pkg="my_package" exec="talker" name="talker" output="screen"/>
</launch>
```

> ROS2ではPython launchが主流だが、XML形式（`.launch.xml`）も `ros2 launch` で使用可能。

---

## E. Unitテストの移行

**ROS1**
```xml
<test test-name="my_test" pkg="my_pkg" type="test_node" />
```

**ROS2**
```cpp
#include <gtest/gtest.h>
TEST(MyTestSuite, simple_test) {
  ASSERT_EQ(1, 1);
}
```
CMakeLists.txt に以下を追加：
```cmake
find_package(ament_cmake_gtest REQUIRED)
ament_add_gtest(my_test test/test_node.cpp)
```

---

## F. メッセージファイルのinclude変更点

| 要素 | ROS1 | ROS2 |
|------|------|------|
| include形式 | `#include <std_msgs/String.h>` | `#include "std_msgs/msg/string.hpp"` |
| 名前空間 | `std_msgs::String` | `std_msgs::msg::String` |

---
