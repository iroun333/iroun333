# ROS2 Humble C++ ノード実装テンプレート集

このドキュメントは、ROS1 NoeticからROS2 Humbleへの移行や新規開発に役立つ、典型的なノード構成テンプレートをまとめたものです。各例はクラス継承型ノード（`rclcpp::Node`）として構成されています。

---

## 1. Publisher ノードテンプレート

**概要**  
周期的にメッセージを発行する基本的なPublisherノードです。トピック名、型、キューサイズを指定して `create_publisher` し、タイマーで定期送信します。

```cpp
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

class SimplePublisher : public rclcpp::Node {
public:
  SimplePublisher() : Node("simple_publisher") {
    publisher_ = this->create_publisher<std_msgs::msg::String>("chatter", 10);
    timer_ = this->create_wall_timer(
      std::chrono::seconds(1),
      [this]() {
        auto msg = std_msgs::msg::String();
        msg.data = "Hello ROS2";
        publisher_->publish(msg);
      });
  }

private:
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<SimplePublisher>());
  rclcpp::shutdown();
  return 0;
}
```

---

## 2. Subscriber ノードテンプレート

**概要**  
指定トピックを購読し、メッセージを受信した際に処理を行う基本的なSubscriberノードです。コールバックにはラムダ式を使用します。

```cpp
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

class SimpleSubscriber : public rclcpp::Node {
public:
  SimpleSubscriber() : Node("simple_subscriber") {
    subscription_ = this->create_subscription<std_msgs::msg::String>(
      "chatter", 10,
      [this](const std_msgs::msg::String::SharedPtr msg) {
        RCLCPP_INFO(this->get_logger(), "Received: '%s'", msg->data.c_str());
      });
  }

private:
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription_;
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<SimpleSubscriber>());
  rclcpp::shutdown();
  return 0;
}
```

---

## 3. Service サーバ テンプレート

**概要**  
クライアントからリクエストを受けて処理結果を返すサービスサーバノードです。ラムダ式で非同期にレスポンスを返す形式です。

```cpp
#include "rclcpp/rclcpp.hpp"
#include "example_interfaces/srv/add_two_ints.hpp"

class SimpleService : public rclcpp::Node {
public:
  SimpleService() : Node("simple_service") {
    service_ = this->create_service<example_interfaces::srv::AddTwoInts>(
      "add_two_ints",
      [this](const std::shared_ptr<example_interfaces::srv::AddTwoInts::Request> request,
             std::shared_ptr<example_interfaces::srv::AddTwoInts::Response> response) {
        response->sum = request->a + request->b;
        RCLCPP_INFO(this->get_logger(), "Service called: %ld + %ld = %ld",
                    request->a, request->b, response->sum);
      });
  }

private:
  rclcpp::Service<example_interfaces::srv::AddTwoInts>::SharedPtr service_;
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<SimpleService>());
  rclcpp::shutdown();
  return 0;
}
```

---

## 4. Timer付きノードテンプレート

**概要**  
周期的な処理（例：状態監視、ログ出力）を行うためのノードです。`create_wall_timer()` により `std::chrono` ベースでタイマーを設定します。

```cpp
#include "rclcpp/rclcpp.hpp"

class TimerNode : public rclcpp::Node {
public:
  TimerNode() : Node("timer_node") {
    timer_ = this->create_wall_timer(
      std::chrono::milliseconds(500),
      [this]() {
        RCLCPP_INFO(this->get_logger(), "Timer triggered");
      });
  }

private:
  rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<TimerNode>());
  rclcpp::shutdown();
  return 0;
}
```

---

## 5. Parameter 宣言と取得テンプレート

**概要**  
パラメータを宣言（declare）して、取得（get）する基本的な構造です。デフォルト値を指定しつつ、外部YAMLファイル等からの上書きも対応できます。

```cpp
#include "rclcpp/rclcpp.hpp"

class ParamNode : public rclcpp::Node {
public:
  ParamNode() : Node("param_node") {
    this->declare_parameter<std::string>("greeting", "Hello");
    std::string greeting;
    this->get_parameter("greeting", greeting);
    RCLCPP_INFO(this->get_logger(), "Parameter [greeting]: %s", greeting.c_str());
  }
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<ParamNode>());
  rclcpp::shutdown();
  return 0;
}
```

---

## 6. 複合ノード（Publisher + Subscriber + Service）

**概要**  
1つのノード内にPublisher、Subscriber、Serviceを組み合わせた構成です。ROS1で複数ノードに分かれていた機能をまとめることができます。

```cpp
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "std_srvs/srv/trigger.hpp"

class HybridNode : public rclcpp::Node {
public:
  HybridNode() : Node("hybrid_node") {
    pub_ = this->create_publisher<std_msgs::msg::String>("out_topic", 10);
    sub_ = this->create_subscription<std_msgs::msg::String>(
      "in_topic", 10,
      [this](const std_msgs::msg::String::SharedPtr msg) {
        RCLCPP_INFO(this->get_logger(), "Subscribed: %s", msg->data.c_str());
      });

    srv_ = this->create_service<std_srvs::srv::Trigger>(
      "trigger",
      [this](const std::shared_ptr<std_srvs::srv::Trigger::Request> req,
             std::shared_ptr<std_srvs::srv::Trigger::Response> res) {
        (void)req;
        auto msg = std_msgs::msg::String();
        msg.data = "Triggered publish!";
        pub_->publish(msg);
        res->success = true;
        res->message = "Message published";
        RCLCPP_INFO(this->get_logger(), "Service triggered");
      });
  }

private:
  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr pub_;
  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr sub_;
  rclcpp::Service<std_srvs::srv::Trigger>::SharedPtr srv_;
};

int main(int argc, char **argv) {
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<HybridNode>());
  rclcpp::shutdown();
  return 0;
}
```

---
