## ✅ ROS2 C++ベストプラクティス 7選

### 1. **クラスのメンバ変数には末尾に `_` をつける**

```cpp
class MyNode : public rclcpp::Node {
public:
  MyNode() : Node("my_node"), counter_(0) {}

private:
  int counter_; // ← クラスメンバには _ を付ける
};
```

📌 **理由**：

* ローカル変数や引数と区別がつきやすい
* 変数名の衝突を避けられる（`this->counter_`と明示しなくても明瞭）

---

### 2. **スマートポインタは明示的に使う（`shared_ptr` / `unique_ptr`）**

```cpp
rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
```

📌 **ポイント**：

* `SharedPtr` / `UniquePtr` 型エイリアスは `rclcpp` に定義されており、積極活用されている
* `new` は使わず `std::make_shared<>` を使う

---

### 3. **関数名やクラス名の命名規則（Google C++ Style準拠）**

| 要素     | 命名規則例                                            |
| ------ | ------------------------------------------------ |
| クラス名   | `CamelCase`（例：`MyNode`）                          |
| メソッド   | `camelCase`（例：`doSomething()`）                   |
| 定数・列挙体 | `kPrefixUpperCase` または `ALL_CAPS`（例：`kMaxSpeed`） |
| ファイル名  | `snake_case.cpp`                                 |

---

### 4. **`this->` を省略できる設計を心がける**

```cpp
timer_ = this->create_wall_timer(...);  // OK
publisher_->publish(msg);              // OK
```

* `this->` は冗長な場合は省略OK
* ただし、ローカル変数とメンバ変数が同名にならないように `_` を使っておくのがポイント

---

### 5. **QoS設定は必ず明示する**

```cpp
rclcpp::QoS qos(rclcpp::KeepLast(10));
publisher_ = this->create_publisher<std_msgs::msg::String>("topic", qos);
```

📌 **理由**：

* デフォルト設定に依存しない（DDS実装依存で変わることがある）

---

### 6. **Launchファイルでの設定値をノードにパラメータとして渡す**

```cpp
this->declare_parameter<int>("loop_rate", 10);
this->get_parameter("loop_rate", loop_rate_);
```

* ROS2ではノード単位でのパラメータ管理が重要
* `declare_parameter` で初期値を設定しないと `get_parameter` が失敗する

---

### 7. **インクルードガードや名前空間の整理**

```cpp
namespace my_package
{
class MyNode : public rclcpp::Node { ... };
}  // namespace my_package
```

* パッケージ名や機能単位で名前空間を整理
* `.hpp` ファイルにはヘッダガードではなく `#pragma once` も一般的に許容される（ROS2はmodern C++）

---

## 🎁 おまけ：推奨されるコード構成（ファイル単位）

| ファイル                       | 内容                                              |
| -------------------------- | ----------------------------------------------- |
| `my_node.cpp`              | ノードのmain処理（main関数含む）                            |
| `my_node.hpp`              | クラス定義（メンバ変数、関数）                                 |
| `CMakeLists.txt`           | `add_executable`, `ament_target_dependencies` 等 |
| `package.xml`              | `build_depend`, `exec_depend` 等                 |
| `launch/my_node.launch.py` | 起動とパラメータ読み込み                                    |

---

## 📝 まとめ：よくある書き方スタイル

```cpp
class MyNode : public rclcpp::Node {
public:
  MyNode() : Node("my_node") {
    publisher_ = this->create_publisher<std_msgs::msg::String>("chatter", 10);
    timer_ = this->create_wall_timer(500ms, std::bind(&MyNode::onTimer, this));
  }

private:
  void onTimer() {
    auto msg = std_msgs::msg::String();
    msg.data = "Hello!";
    publisher_->publish(msg);
  }

  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
  rclcpp::TimerBase::SharedPtr timer_;
};
```

---

## 📚 参考スタイルガイド

* [ROS 2 C++ Style Guide (Design)](https://index.ros.org/doc/ros2/Contributing/Developer-Guide/#c-coding-style)
* [Google C++ Style Guide](https://google.github.io/styleguide/cppguide.html)
* [rclcpp examples (ros2/examples repo)](https://github.com/ros2/examples)

