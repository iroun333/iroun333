# 📂 ステップ1：現行パッケージの整理と要素分解

## 1. `package.xml` の確認：ROS1（catkin）からROS2（ament）への移行準備

### ✅ 目的

`package.xml` は、パッケージが**他のパッケージとどう依存関係を持つか**、**ビルド・実行時に何が必要か**を記述するメタ情報ファイルです。
移行時には、これを **ROS2の依存管理（ament準拠）** に変換する必要があります。

---

### ✅ チェックポイント（Noeticにおける `package.xml`）

```xml
<package format="2">
  <name>my_package</name>
  <version>0.0.1</version>
  <description>Example package</description>

  <maintainer email="you@example.com">Your Name</maintainer>
  <license>MIT</license>

  <buildtool_depend>catkin</buildtool_depend>

  <build_depend>roscpp</build_depend>
  <build_depend>std_msgs</build_depend>

  <exec_depend>roscpp</exec_depend>
  <exec_depend>std_msgs</exec_depend>

  <export>
    <build_type>catkin</build_type>
  </export>
</package>
```

---

### ✅ 確認すべき要素と移行対応

| 項目                      | 内容                                         | 移行上の注意点                                                  |
| ----------------------- | ------------------------------------------ | -------------------------------------------------------- |
| `<buildtool_depend>`    | ROS1は `catkin`、ROS2では `ament_cmake` に置き換える | `catkin` → `ament_cmake`                                 |
| `<build_depend>`        | ビルド時に必要な依存（例：`roscpp`, `sensor_msgs`）      | ROS2でも同様だが、全依存を `ament_target_dependencies()` に指定する必要がある |
| `<exec_depend>`         | 実行時に必要な依存                                  | ROS2では、`<test_depend>` なども含めて適切に分類                       |
| `<build_export_depend>` | ビルド結果を使う他パッケージに必要な依存                       | ROS2では `<depend>` にまとめることもある（明示的記述が望ましい）                 |
| `<export>`              | `catkin`のビルド型を宣言                           | ROS2では `build_type` に `ament_cmake` を設定（または省略）           |

---

### ✅ よくある依存例と用途

| パッケージ名                                   | 用途                    | ROS2移行時の確認点                                                         |
| ---------------------------------------- | --------------------- | ------------------------------------------------------------------- |
| `roscpp`                                 | ROSノード開発の基本           | ROS2では `rclcpp` に変更                                                 |
| `std_msgs`                               | 標準メッセージ型              | ROS2でも継続利用可能                                                        |
| `sensor_msgs`                            | センサーデータ用（例：LaserScan） | ROS2に対応しているが依存は明記必要                                                 |
| `tf` / `tf2`                             | 座標変換ライブラリ             | ROS2では `tf2_ros`, `tf2_geometry_msgs` などに細分化                        |
| `message_generation` / `message_runtime` | カスタムmsg/srvの生成に必要     | ROS2では `rosidl_default_generators`, `rosidl_default_runtime` に置き換える |

---

### ✅ ROS2用の `package.xml` 例（format=3）

```xml
<package format="3">
  <name>my_package</name>
  <version>0.0.1</version>
  <description>Example ROS2 package</description>
  <maintainer email="you@example.com">Your Name</maintainer>
  <license>MIT</license>

  <buildtool_depend>ament_cmake</buildtool_depend>

  <build_depend>rclcpp</build_depend>
  <build_depend>std_msgs</build_depend>

  <exec_depend>rclcpp</exec_depend>
  <exec_depend>std_msgs</exec_depend>
</package>
```

---

### ✅ 補足：rosdep で補完されるパッケージも明記

`rosdep install` によって自動解決されるパッケージもありますが、**`package.xml` で明示しておくことで再利用性・保守性が高まります**。

---

### ✅ 実作業のすすめ方

1. `package.xml` を読み、依存関係を一覧にする
2. ROS2での対応パッケージ名・バージョンを調査する
3. 不明なパッケージがあれば `ros2 pkg search` で調査
4. 移行先の `package.xml` を format=3 で記述

---
